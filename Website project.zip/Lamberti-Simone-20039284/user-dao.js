'use strict';

// Importazione del modulo SQLite e inizializzazione del database
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');

// Percorso del database SQLite
const DB_PATH = './cities.db';
const db = new sqlite3.Database(DB_PATH);

// Funzione per creare un nuovo utente nel database
exports.createUser = function(user) {
  return new Promise((resolve, reject) => {
    const sql = 'INSERT INTO user(email, password) VALUES (?, ?)';
    bcrypt.hash(user.password, 10).then((hash => {
      db.run(sql, [user.email, hash], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID); // Risolve con l'ID dell'utente appena creato
        }
      });
    })).catch(err => reject(err));
  });
}

// Funzione per ottenere un utente dal database tramite ID
exports.getUserById = function(id) {
  return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM user WHERE id = ?';
      db.get(sql, [id], (err, row) => {
          if (err)
              reject(err);
          else if (row === undefined)
              resolve({error: 'User not found.'});
          else {
              const user = {id: row.id, username: row.email}; // Crea l'oggetto utente
              resolve(user);
          }
      });
  });
};

// Funzione per ottenere un utente dal database tramite email e confrontare la password
exports.getUserByEmail = function(email, password) {
  return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM user WHERE email = ?';
      db.get(sql, [email], (err, row) => {
          if (err)
              reject(err);
          else if (row === undefined)
              resolve({error: 'User not found.'});
          else {
            const user = {id: row.id, username: row.email}; // Crea l'oggetto utente
            let check = false;

            // Confronta la password fornita con quella nel database tramite bcrypt
            if(bcrypt.compareSync(password, row.password))
              check = true;

            resolve({user, check}); // Risolve con l'oggetto utente e un flag di verifica
          }
      });
  });
};

// Funzione per aggiungere una città ai preferiti di un utente
exports.addFavoriteCity = function(userId, cityName) {
  return new Promise((resolve, reject) => {
      db.get('SELECT favorites FROM user WHERE id = ?', [userId], (err, row) => {
          if (err) {
              reject(err);
          } else if (!row) {
              reject(new Error('User not found.'));
          } else {
              let favorites = [];
              if (row.favorites) {
                  favorites = JSON.parse(row.favorites); // Parsa l'array JSON delle città preferite
              }
              
              if (favorites.includes(cityName)) {
                  resolve({ message: `La città ${cityName} è già presente nei tuoi preferiti.`, alreadyExists: true });
              } else {
                  favorites.push(cityName);
                  db.run('UPDATE user SET favorites = ? WHERE id = ?', [JSON.stringify(favorites), userId], function(err) {
                      if (err) {
                          reject(err);
                      } else {
                          resolve({ message: `Città ${cityName} aggiunta ai preferiti con successo.`, alreadyExists: false });
                      }
                  });
              }
          }
      });
  });
};

// Funzione per rimuovere una città dai preferiti di un utente
exports.removeFavoriteCity = function(userId, cityName) {
  return new Promise((resolve, reject) => {
      db.get('SELECT favorites FROM user WHERE id = ?', [userId], (err, row) => {
          if (err) {
              reject(err);
          } else if (!row) {
              reject(new Error('User not found.'));
          } else {
              let favorites = [];
              if (row.favorites) {
                  favorites = JSON.parse(row.favorites); // Parsa l'array JSON delle città preferite
              }

              const index = favorites.indexOf(cityName);
              if (index > -1) {
                  favorites.splice(index, 1); // Rimuove la città dall'array
                  db.run('UPDATE user SET favorites = ? WHERE id = ?', [JSON.stringify(favorites), userId], function(err) {
                      if (err) {
                          reject(err);
                      } else {
                          resolve({ message: `Città ${cityName} rimossa dai preferiti con successo.`, notExists: false });
                      }
                  });
              } else {
                  resolve({ message: `La città ${cityName} non è presente nei tuoi preferiti.`, notExists: true });
              }
          }
      });
  });
};

// Funzione per ottenere le città preferite di un utente
exports.getUserFavorites = function(userId) {
  return new Promise((resolve, reject) => {
      // Query per recuperare le città preferite dell'utente dal database
      db.get('SELECT favorites FROM user WHERE id = ?', [userId], (err, row) => {
          if (err) {
              reject(err);
          } else if (!row || !row.favorites) {
              resolve([]);  // Restituisce un array vuoto se non ci sono città preferite
          } else {
              const favorites = JSON.parse(row.favorites); // Parsa l'array JSON delle città preferite
              
              if (favorites.length === 0) {
                  resolve([]);  // Restituisce un array vuoto se l'elenco delle città preferite è vuoto
              } else {
                  // Ottieni i dettagli delle città preferite dal database delle città
                  const placeholders = favorites.map(() => '?').join(',');
                  const query = `SELECT * FROM cities WHERE name IN (${placeholders})`;
                  
                  db.all(query, favorites, (err, rows) => {
                      if (err) {
                          reject(err);
                      } else {
                          resolve(rows); // Risolve con l'array delle città preferite dell'utente
                      }
                  });
              }
          }
      });
  });
};
