const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');

// Definizione del percorso del database SQLite
const DB_PATH = './cities.db';

// Funzione per inizializzare il database e creare la tabella se non esiste
function initializeDatabase() {
   
    const db = new sqlite3.Database(DB_PATH, (err) => {
        if (err) {
            console.error('Errore durante l\'apertura del database:', err.message);
        } else {
            console.log('Connesso al database SQLite.');

            //Creazione tabella utenti se non esiste già
            db.run(`CREATE TABLE IF NOT EXISTS user (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                favorites TEXT
              )`, function(err) {
                  if (err) {
                    console.error(err);
                  } else {
                    console.log('Tabella users creata con successo');
                  }
              });

              db.run(`CREATE TABLE IF NOT EXISTS ratings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                city_name TEXT NOT NULL,
                rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 10),
                UNIQUE(user_id, city_name),
                FOREIGN KEY (user_id) REFERENCES user(id),
                FOREIGN KEY (city_name) REFERENCES cities(name)
              )`, function(err) {
                if (err) {
                  console.error(err);
                } else {
                  console.log('Tabella ratings creata con successo');
                }
              });
            // Creazione della tabella cities se non esiste
            db.run(`CREATE TABLE IF NOT EXISTS cities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                foundation_year TEXT,
                population INTEGER,
                currency TEXT,
                language TEXT,
                area TEXT,
                timezone TEXT,
                cover_image TEXT,
                main_image TEXT,
                background_image1 TEXT,
                background_image2 TEXT,
                background_image3 TEXT,
                flag_image TEXT,
                detailed_description TEXT,
                average_rating REAL
            )`, (err) => {
                if (err) {
                    console.error('Errore durante la creazione della tabella cities:', err.message);
                } else {
                    console.log('Tabella cities creata con successo.');

                    // Inserimento delle città di esempio nel database se la tabella è vuota
                    db.get(`SELECT count(*) as count FROM cities`, (err, row) => {
                        if (err) {
                            console.error('Errore durante il controllo delle città nel database:', err.message);
                        } else {
                            const count = row.count;
                            if (count === 0) {

                                // Città da inserire
                                const cities = [
                                    {
                                        name: 'New York',
                                        description: 'La Grande Mela',
                                        foundation_year: '1624',
                                        population: 8336817,
                                        currency: 'Dollaro statunitense',
                                        language: 'Inglese',
                                        area: '789 km quadrati',
                                        timezone: 'UTC-5',
                                        cover_image: 'img/newyork/new-york-cover.jpg',  
                                        main_image: 'img/newyork/new-york-main.jpg',    
                                        background_image1: 'img/newyork/new-york-bg1.jpg',
                                        background_image2: 'img/newyork/new-york-bg2.jpg',
                                        background_image3: 'img/newyork/new-york-bg3.jpg',
                                        flag_image: 'img/newyork/usa-flag.png',
                                        detailed_description: `New York City, spesso chiamata semplicemente New York (NYC), è una delle città più iconiche e influenti del mondo. La sua storia ricca e complessa risale a quasi quattro secoli fa, quando fu fondata dai coloni olandesi nel 1624 con il nome di “Nuova Amsterdam” in onore della città olandese. Nel 1664, la città fu conquistata dagli inglesi e ribattezzata “New York” in onore del Duca di York, che in seguito divenne re Giacomo II d’Inghilterra. Durante il XVIII e XIX secolo, New York crebbe rapidamente diventando un importante centro commerciale e culturale. Il suo porto naturale la trasformò in una delle principali porte d’ingresso per l’immigrazione verso gli Stati Uniti, con milioni di persone provenienti da tutto il mondo che cercavano fortuna e libertà nelle sue strade.

                                        Durante il XIX secolo, New York City si trasformò rapidamente in un centro finanziario globale, con la nascita di Wall Street e la creazione della Borsa di New York. L’epoca dell’industrializzazione portò una crescita senza precedenti, ma anche gravi disuguaglianze sociali e problemi di sovraffollamento e condizioni di vita insalubri. Nel corso del XX secolo, New York City ha vissuto alti e bassi, affrontando sfide come la Grande Depressione, il declino urbano degli anni ’70 e ’80, e gli attacchi dell’11 settembre 2001. Tuttavia, la città ha dimostrato una straordinaria resilienza, ripresa e continuando a prosperare come uno dei principali centri culturali, finanziari, e commerciali del mondo.
                                       
                                        Oggi, New York City è conosciuta per i suoi grattacieli iconici come l’Empire State Building e il One World Trade Center, i suoi quartieri vibranti come Times Square e Greenwich Village, la sua ricca scena artistica e culturale, e la sua diversità etnica e culinaria. È una città che continua a ispirare e attrarre milioni di persone da tutto il mondo con il suo spirito vibrante e la sua energia senza fine.`

                                    },
                                    {
                                        name: 'Parigi',
                                        description: 'La città dell’amore',
                                        foundation_year: '52 a.C.',
                                        population: 2140526,
                                        currency: 'Euro',
                                        language: 'Francese',
                                        area: '105 km quadrati',  
                                        timezone: 'UTC+1',
                                        cover_image: 'img/parigi/parigi-cover.jpg', 
                                        main_image: 'img/parigi/parigi-main.jpg',    
                                        background_image1: 'img/parigi/parigi-bg1.jpg', 
                                        background_image2: 'img/parigi/parigi-bg2.jpg',
                                        background_image3: 'img/parigi/parigi-bg3.jpg',
                                        flag_image: 'img/parigi/france-flag.jpg',
                                        detailed_description: `Parigi, spesso chiamata “la Ville Lumière”, è una delle città più romantiche e affascinanti del mondo. La sua storia millenaria risale ai tempi dei Celti, quando era conosciuta come Lutetia. Con l’avvento dei Romani, divenne un importante centro della Gallia. Nel 508 d.C., Parigi fu scelta da Clodoveo I come capitale del regno dei Franchi, consolidando il suo ruolo centrale nella storia francese. Durante il Medioevo, Parigi si affermò come un centro religioso e commerciale, con la costruzione della Cattedrale di Notre-Dame e la fondazione dell’Università della Sorbona. Nel Rinascimento, la città fiorì come un polo artistico e culturale, attirando intellettuali e artisti da tutta Europa.

                                        Il XVIII secolo segnò un periodo tumultuoso con la Rivoluzione Francese, durante la quale Parigi fu teatro di eventi storici cruciali, come la presa della Bastiglia e la dichiarazione dei diritti dell’uomo e del cittadino. Nel XIX secolo, sotto Napoleone III e il prefetto Haussmann, Parigi fu trasformata con ampi boulevards, parchi e monumenti che ancora oggi ne caratterizzano l’aspetto. L’Esposizione Universale del 1889, che vide la costruzione della Torre Eiffel, consacrò Parigi come capitale mondiale della cultura e dell’innovazione.
                                       
                                        Nel XX secolo, Parigi continuò a essere un faro culturale e politico, sopravvivendo a due guerre mondiali e divenendo un simbolo di resistenza durante l’occupazione nazista. Dopo la guerra, la città si rigenerò e divenne un centro dell’arte moderna, della moda e della filosofia esistenzialista. Oggi, Parigi è conosciuta per i suoi musei di fama mondiale come il Louvre e il Musée d’Orsay, i suoi quartieri storici come Montmartre e Le Marais, e la sua cucina raffinata. La città continua a essere un importante centro finanziario, culturale e turistico, attirando milioni di visitatori ogni anno con il suo fascino senza tempo, la sua architettura elegante e la sua vivace scena artistica. Parigi rimane una città che incanta e ispira, simbolo di bellezza, storia e innovazione.`
                                    },
                                    {
                                        name: 'Roma',
                                        description: 'La città eterna',
                                        foundation_year: '753 a.C.',
                                        population: 2872800,
                                        currency: 'Euro',
                                        language: 'Italiano',
                                        area: '1285 km quadrati', 
                                        timezone: 'UTC+1',
                                        cover_image: 'img/roma/roma-cover.jpg',  
                                        main_image: 'img/roma/roma-main.jpg',    
                                        background_image1: 'img/roma/roma-bg1.jpg', 
                                        background_image2: 'img/roma/roma-bg2.jpg',
                                        background_image3: 'img/roma/roma-bg3.jpg',
                                        flag_image: 'img/roma/italy-flag.jpg',
                                        detailed_description: `Roma, spesso chiamata “la Città Eterna”, è una delle città più antiche e influenti del mondo. La sua storia millenaria risale alla fondazione leggendaria da parte di Romolo e Remo nel 753 a.C. Come cuore dell’Impero Romano, Roma dominò gran parte dell’Europa, dell’Asia Minore e del Nord Africa per secoli, diventando un centro di cultura, politica e religione. Durante il Medioevo, Roma fu il centro spirituale del Cristianesimo, con la costruzione di numerose chiese e basiliche, tra cui la Basilica di San Pietro in Vaticano.

                                        Nel Rinascimento, Roma conobbe un periodo di straordinaria fioritura artistica e architettonica, attirando artisti come Michelangelo e Raffaello, e dando vita a capolavori come la Cappella Sistina e Piazza San Pietro. Il Barocco lasciò un’impronta indelebile sulla città con le opere di Bernini e Borromini. Durante il XIX secolo, Roma divenne il fulcro del Risorgimento italiano e, nel 1870, fu proclamata capitale del Regno d’Italia.
                                       
                                        Nel XX secolo, Roma ha vissuto una crescita demografica e urbanistica significativa, affrontando sia le difficoltà della Seconda Guerra Mondiale che la successiva ricostruzione. Oggi, Roma è conosciuta per i suoi monumenti storici come il Colosseo, il Pantheon e il Foro Romano, nonché per la Città del Vaticano, sede del Papa e centro della Chiesa Cattolica. La città è un vivace centro di cultura, arte e cucina, con una ricca tradizione culinaria e una vita notturna animata.
                                       
                                        Roma continua ad attrarre milioni di visitatori ogni anno, affascinati dalla sua storia antica, dalla sua bellezza architettonica e dal suo spirito vibrante. È una città che incanta e ispira, simbolo di storia, cultura e innovazione.`
                                    },
                                    {
                                        name: 'Cairo',
                                        description: 'Il cuore dell’Egitto',
                                        foundation_year: '969 a.C.',
                                        population: 9813807,
                                        currency: 'Sterlina egiziana',
                                        language: 'Arabo',
                                        area: '3085 km quadrati',  
                                        timezone: 'UTC+2',
                                        cover_image: 'img/cairo/cairo-cover.jpg',  
                                        main_image: 'img/cairo/cairo-main.jpg',    
                                        background_image1: 'img/cairo/cairo-bg1.jpg',  
                                        background_image2: 'img/cairo/cairo-bg2.jpg',
                                        background_image3: 'img/cairo/cairo-bg3.jpg',
                                        flag_image: 'img/cairo/egypt-flag.jpg',
                                        detailed_description: `Il Cairo, capitale dell’Egitto, è una delle città più antiche e affascinanti del mondo. Fondata nel 969 d.C. dai Fatimidi, la città ha una storia che si intreccia con le grandi civiltà dell’antico Egitto, della Grecia, di Roma e dell’Islam. Situata vicino alle leggendarie Piramidi di Giza e alla Sfinge, Il Cairo è un ponte tra il passato faraonico e la modernità contemporanea. La città è cresciuta rapidamente diventando un importante centro culturale, religioso e commerciale nel mondo islamico.

                                        Durante il periodo medievale, Il Cairo fiorì come un centro di sapere e cultura islamica, ospitando prestigiose istituzioni come l’Università di al-Azhar, una delle più antiche università del mondo. Nel corso dei secoli, la città si è arricchita di splendidi esempi di architettura islamica, tra cui moschee, madrase e palazzi.
                                       
                                        Nel XIX e XX secolo, Il Cairo ha continuato a crescere e modernizzarsi, diventando il cuore pulsante della politica, della cultura e dell’economia egiziana. La città ha vissuto periodi di turbolenza e trasformazione, compresi gli anni della colonizzazione britannica e la rivoluzione egiziana del 1952 che portò alla nascita della Repubblica.
                                       
                                        Oggi, Il Cairo è una metropoli vibrante e caotica, conosciuta per la sua ricca storia, i suoi mercati animati come il Khan el-Khalili, e i suoi quartieri contrastanti dove l’antico e il moderno convivono. La città è un centro culturale dinamico, con musei di fama mondiale come il Museo Egizio, che ospita una vasta collezione di antichità faraoniche, e una scena artistica e musicale vivace.
                                       
                                        Il Cairo continua ad attrarre milioni di visitatori ogni anno, affascinati dalle sue meraviglie storiche, dalla sua cultura vibrante e dalla sua energia inesauribile. È una città che incanta e ispira, simbolo di una storia millenaria e di una continua evoluzione.`
                                    },
                                    {
                                        name: 'Copenaghen',
                                        description: 'La regina del Baltico',
                                        foundation_year: '1167',
                                        population: 1085000,
                                        currency: 'Corona danese',
                                        language: 'Danese',
                                        area: '88 km quadrati',  
                                        timezone: 'UTC+1',
                                        cover_image: 'img/copenaghen/copenaghen-cover.jpg',  
                                        main_image: 'img/copenaghen/copenaghen-main.jpg',   
                                        background_image1: 'img/copenaghen/copenaghen-bg1.jpg', 
                                        background_image2: 'img/copenaghen/copenaghen-bg2.jpg',
                                        background_image3: 'img/copenaghen/copenaghen-bg3.jpg',
                                        flag_image: 'img/copenaghen/denmark-flag.jpg',
                                        detailed_description: `Copenaghen, la capitale della Danimarca, è una città che combina storia, cultura e modernità in un modo unico. Fondata come villaggio di pescatori nel X secolo, Copenaghen divenne un importante centro commerciale durante il Medioevo, grazie alla sua posizione strategica sul Mar Baltico. Nel XV secolo, la città fu scelta come capitale del Regno di Danimarca, segnando l'inizio di un periodo di grande crescita e sviluppo.

                                        Durante il Rinascimento, Copenaghen fiorì sotto il regno di Cristiano IV, che commissionò molti degli edifici storici che ancora oggi caratterizzano la città, come il Castello di Rosenborg e la Rundetårn. Nel corso dei secoli, la città ha affrontato sfide come incendi devastanti e guerre, ma ha sempre saputo risorgere e reinventarsi.
                                       
                                        Nel XIX secolo, Copenaghen si trasformò in un centro culturale e intellettuale, con la nascita del famoso Tivoli Gardens e la costruzione della Glyptotek, un importante museo di arte e cultura. La città ha anche giocato un ruolo cruciale durante l'Età dell'Oro danese, un periodo di grande fioritura artistica e scientifica.
                                       
                                        Oggi, Copenaghen è conosciuta per la sua alta qualità della vita, la sostenibilità e il design innovativo. È una città che vanta una scena culinaria di livello mondiale, con numerosi ristoranti stellati Michelin, e una forte tradizione di ciclismo urbano, con più biciclette che abitanti. La città è anche sede di attrazioni iconiche come la Sirenetta, il Palazzo di Amalienborg e il moderno quartiere di Ørestad.
                                       
                                        Copenaghen continua ad attirare milioni di visitatori ogni anno, affascinati dalla sua combinazione di tradizione e innovazione, dalla sua bellezza architettonica e dalla sua atmosfera accogliente. È una città che incanta e ispira, simbolo di progresso, cultura e benessere.`
                                    },
                                    {
                                        name: 'Edimburgo',
                                        description: 'La città vecchia',
                                        foundation_year: '1329',
                                        population: 488050,
                                        currency: 'Sterlina britannica',
                                        language: 'Inglese',
                                        area: '264 km quadrati', 
                                        timezone: 'UTC+0',
                                        cover_image: 'img/edimburgo/edimburgo-cover.jpg', 
                                        main_image: 'img/edimburgo/edimburgo-main.jpg',    
                                        background_image1: 'img/edimburgo/edimburgo-bg1.jpg',  
                                        background_image2: 'img/edimburgo/edimburgo-bg2.jpg',
                                        background_image3: 'img/edimburgo/edimburgo-bg3.jpg',
                                        flag_image: 'img/edimburgo/scotland-flag.jpg',
                                        detailed_description: `Edimburgo, capitale della Scozia, è una città ricca di storia, cultura e paesaggi mozzafiato. Fondata nel Medioevo, la città è stata per secoli il centro della politica e della cultura scozzese. Il suo imponente castello, situato su un'antica rocca vulcanica, domina lo skyline e racconta storie di battaglie e re.

                                        Durante il Rinascimento, Edimburgo divenne un importante centro intellettuale grazie alla fondazione dell'Università di Edimburgo nel 1582, una delle più prestigiose al mondo. Il periodo dell'Illuminismo scozzese nel XVIII secolo vide la città emergere come un faro di progresso intellettuale, con figure di spicco come David Hume e Adam Smith che contribuirono a fare di Edimburgo un centro di pensiero filosofico ed economico.
                                       
                                        Il XIX secolo portò ulteriore crescita e sviluppo, con la costruzione della New Town, un capolavoro di architettura georgiana che contrasta con la storica Old Town. Questo mix di antico e moderno conferisce a Edimburgo il suo carattere unico e affascinante.
                                       
                                        Oggi, Edimburgo è famosa per i suoi festival culturali, in particolare l'Edinburgh International Festival e il Fringe Festival, che attraggono artisti e visitatori da tutto il mondo. La città è anche conosciuta per la sua ricca scena letteraria, essendo stata la casa di scrittori come Sir Walter Scott, Robert Louis Stevenson e J.K. Rowling.
                                       
                                        Edimburgo vanta numerose attrazioni storiche e culturali, tra cui il Palazzo di Holyroodhouse, la residenza ufficiale della regina in Scozia, e il Royal Mile, una strada storica che collega il castello al palazzo. I suoi parchi e spazi verdi, come Holyrood Park e i Giardini di Princes Street, offrono oasi di tranquillità nel cuore della città.
                                       
                                        Edimburgo continua ad affascinare milioni di visitatori ogni anno con il suo mix di storia, cultura e bellezza naturale. È una città che incanta e ispira, simbolo di eredità storica e vitalità contemporanea.`
                                    },
                                    {
                                        name: 'Toronto',
                                        description: 'La porta del nord',
                                        foundation_year: '1793',
                                        population: 2731571,
                                        currency: 'Dollaro canadese',
                                        language: 'Inglese',
                                        area: '630 km quadrati', 
                                        timezone: 'UTC-5',
                                        cover_image: 'img/toronto/toronto-cover.jpg',  
                                        main_image: 'img/toronto/toronto-main.jpg',    
                                        background_image1: 'img/toronto/toronto-bg1.jpg',  
                                        background_image2: 'img/toronto/toronto-bg2.jpg',
                                        background_image3: 'img/toronto/toronto-bg3.jpg',
                                        flag_image: 'img/toronto/canada-flag.jpg',
                                        detailed_description: `Toronto, la più grande città del Canada, è un vivace centro di cultura, commercio e innovazione. Fondata nel XVIII secolo come forte britannico, Toronto divenne una città nel 1834 e crebbe rapidamente grazie alla sua posizione strategica sul Lago Ontario. Nel corso del XIX e XX secolo, la città si trasformò in un importante centro industriale e finanziario, attirando immigrati da tutto il mondo.

                                        Durante il XX secolo, Toronto continuò a espandersi e modernizzarsi, diventando la capitale economica del Canada e uno dei principali centri finanziari del mondo. La città è conosciuta per la sua diversità culturale, con oltre metà dei suoi abitanti nati al di fuori del Canada, rendendola una delle città più multietniche del pianeta.
                                       
                                        Oggi, Toronto è famosa per il suo skyline iconico dominato dalla CN Tower, una delle strutture autoportanti più alte del mondo. La città è anche un centro culturale di primo piano, ospitando istituzioni di fama mondiale come la Art Gallery of Ontario, il Royal Ontario Museum e la Toronto Symphony Orchestra. Ogni anno, Toronto ospita il Toronto International Film Festival (TIFF), uno degli eventi cinematografici più prestigiosi a livello internazionale.
                                       
                                        Toronto è rinomata per i suoi quartieri distintivi, ognuno con il proprio carattere unico. Da Chinatown a Little Italy, da Greektown a Kensington Market, la città offre un mosaico di culture, cucine e tradizioni. La vibrante scena gastronomica di Toronto spazia dai ristoranti gourmet ai mercati alimentari, riflettendo la ricchezza della sua diversità culturale.
                                       
                                        La città è anche un importante centro di istruzione e ricerca, sede di numerose università e college di fama mondiale, come l'Università di Toronto. Toronto è leader in molti settori, tra cui tecnologia, finanza, e cinema, e continua ad attrarre investimenti e talenti da tutto il mondo.
                                       
                                        Toronto continua a crescere e prosperare, offrendo un mix dinamico di innovazione, cultura e qualità della vita. È una città che incanta e ispira, simbolo di opportunità e diversità.`

                                    },
                                    {
                                        name: 'Reykjavik',
                                        description: 'La città dei ghiacci',
                                        foundation_year: '874',
                                        population: 131136,
                                        currency: 'Corona islandese',
                                        language: 'Islandese',
                                        area: '273 km quadrati',  
                                        timezone: 'UTC+0',
                                        cover_image: 'img/reykjavik/reykjavik-cover.jpg', 
                                        main_image: 'img/reykjavik/reykjavik-main.jpg',    
                                        background_image1: 'img/reykjavik/reykjavik-bg1.jpg',  
                                        background_image2: 'img/reykjavik/reykjavik-bg2.jpg',
                                        background_image3: 'img/reykjavik/reykjavik-bg3.jpg',
                                        flag_image: 'img/reykjavik/iceland-flag.jpg',
                                        detailed_description: `Reykjavik, la capitale dell'Islanda, è una città unica e affascinante, circondata da paesaggi mozzafiato e ricca di cultura nordica. Fondata nel IX secolo dai coloni norvegesi, Reykjavik è la città più settentrionale del mondo e il cuore pulsante dell'Islanda moderna.

                                        Nonostante la sua giovane età come città, Reykjavik è ricca di storia e tradizioni, che si riflettono nelle sue strade acciottolate e nei suoi edifici colorati. La città è famosa per la sua architettura eclettica, che va dalle vecchie case in legno ai moderni edifici in vetro e acciaio.
                                       
                                        Reykjavik è anche un importante centro culturale, con una vivace scena artistica e musicale. La città ospita numerosi festival durante tutto l'anno, tra cui il famoso Iceland Airwaves, che attira artisti e musicisti da tutto il mondo. Reykjavik è anche nota per la sua vita notturna animata, con numerosi bar, club e caffetterie che offrono intrattenimento fino alle prime ore del mattino.
                                       
                                        Ma Reykjavik non è solo una città di divertimento; è anche un punto di partenza ideale per esplorare la spettacolare natura dell'Islanda. Dalle famose terme geotermali alle maestose cascate, dai vulcani attivi ai ghiacciai imponenti, i paesaggi intorno a Reykjavik sono semplicemente mozzafiato.
                                       
                                        La città è anche un centro di benessere e relax, con numerose spa e centri termali dove è possibile rilassarsi e rigenerarsi dopo una giornata di esplorazione.
                                       
                                        Reykjavik è una città che incanta e affascina, con la sua combinazione unica di storia, cultura e natura. È il luogo perfetto per chiunque cerchi avventura, bellezza e tranquillità nel cuore del Nord Atlantico.`
                                    },
                                    {
                                        name: 'Amsterdam',
                                        description: 'La Venezia del nord',
                                        foundation_year: '1275',
                                        population: 872680,
                                        currency: 'Euro',
                                        language: 'Olandese',
                                        area: '219 km quadrati', 
                                        timezone: 'UTC+1',
                                        cover_image: 'img/amsterdam/amsterdam-cover.jpg',  
                                        main_image: 'img/amsterdam/amsterdam-main.jpg',    
                                        background_image1: 'img/amsterdam/amsterdam-bg1.jpg',  
                                        background_image2: 'img/amsterdam/amsterdam-bg2.jpg',
                                        background_image3: 'img/amsterdam/amsterdam-bg3.jpg',
                                        flag_image: 'img/amsterdam/netherland-flag.jpg',
                                        detailed_description: `Amsterdam, la capitale dei Paesi Bassi, è una città unica e affascinante, famosa per i suoi canali pittoreschi, la sua ricca storia e la sua cultura vivace. Fondata nel XII secolo come un piccolo villaggio di pescatori sul fiume Amstel, Amsterdam è cresciuta fino a diventare una delle principali città del mondo.

                                        Il suo labirinto di canali è una delle caratteristiche distintive di Amsterdam, e molti dei suoi edifici storici risalgono al periodo d'oro del XVII secolo, quando la città era un importante centro di commercio e cultura. Amsterdam è nota per la sua architettura distintiva, che spazia dai palazzi storici alle moderne strutture di vetro e acciaio.
                                       
                                        La città è un importante centro culturale, con numerose gallerie d'arte, musei e teatri. Il Rijksmuseum ospita una vasta collezione di opere d'arte olandesi, tra cui i capolavori di artisti come Rembrandt e Vermeer, mentre il Van Gogh Museum è dedicato alla vita e all'opera del famoso pittore olandese. Amsterdam è anche sede di una vivace scena musicale e teatrale, con numerosi festival e spettacoli che si tengono durante tutto l'anno.
                                       
                                        Ma Amsterdam non è solo cultura e storia; è anche una città vibrante e cosmopolita, con una popolazione diversificata e una vita notturna animata. I suoi quartieri caratteristici, come il Jordaan e il Pijp, offrono una vasta gamma di ristoranti, caffè e bar, dove è possibile gustare la cucina olandese e internazionale e immergersi nell'atmosfera locale.
                                       
                                        Amsterdam è anche famosa per la sua mentalità aperta e progressista, ed è stata una delle prime città al mondo a legalizzare il matrimonio tra persone dello stesso sesso e la cannabis. La sua atmosfera tollerante e inclusiva la rende una destinazione popolare per viaggiatori di ogni genere.
                                       
                                        Inoltre, Amsterdam è circondata da una natura mozzafiato, con parchi urbani, boschi e campagne pittoresche a breve distanza in bicicletta. La bicicletta è il mezzo di trasporto preferito dagli abitanti di Amsterdam e offre un modo divertente e sostenibile per esplorare la città e i suoi dintorni.
                                       
                                        Amsterdam è una città che incanta e ispira, con la sua bellezza architettonica, la sua ricca storia e la sua cultura cosmopolita. È un luogo dove passato e presente si fondono in un'esperienza indimenticabile.`
                                    },
                                    {
                                        name: 'Madrid',
                                        description: 'La capitale del flamenco',
                                        foundation_year: '860',
                                        population: 3334730,
                                        currency: 'Euro',
                                        language: 'Spagnolo',
                                        area: '604 km quadrati', 
                                        timezone: 'UTC+1',
                                        cover_image: 'img/madrid/madrid-cover.jpg', 
                                        main_image: 'img/madrid/madrid-main.jpg',    
                                        background_image1: 'img/madrid/madrid-bg1.jpg', 
                                        background_image2: 'img/madrid/madrid-bg2.jpg',
                                        background_image3: 'img/madrid/madrid-bg3.jpg',
                                        flag_image: 'img/madrid/spain-flag.jpg',
                                        detailed_description: `Madrid, la capitale della Spagna, è una città vibrante e affascinante, con una ricca storia, una cultura vivace e una vivace scena artistica. Fondata nel IX secolo durante l'epoca della dominazione musulmana, Madrid divenne la capitale del Regno di Spagna nel XVI secolo, durante il regno di Carlo V.

                                        La città è caratterizzata da una magnifica architettura, che va dalle antiche strade medievali alle maestose piazze e agli imponenti palazzi reali. Madrid è sede di alcuni dei più importanti musei d'arte del mondo, tra cui il famoso Museo del Prado, che ospita una vasta collezione di opere di artisti come Velázquez, Goya, El Greco e Bosch.
                                       
                                        Ma Madrid non è solo cultura e storia; è anche una città moderna e cosmopolita, con una vivace vita notturna, una scena gastronomica eccezionale e una serie di eventi e festival tutto l'anno. I suoi quartieri caratteristici, come La Latina e Chueca, offrono una vasta gamma di bar, ristoranti e club, dove è possibile gustare la cucina spagnola e internazionale e immergersi nell'atmosfera locale.
                                       
                                        Madrid è anche una città verde, con numerosi parchi e giardini dove è possibile rilassarsi e godersi la natura in mezzo alla frenesia della città. Il Parco del Retiro è uno dei parchi più grandi e famosi di Madrid, con laghi, fontane e una varietà di piante e alberi.
                                       
                                        La città è anche un importante centro commerciale e finanziario, con una fiorente industria turistica e una forte presenza nel settore delle telecomunicazioni, della moda e delle arti. Madrid è una città che non dorme mai, con una vita culturale e sociale vivace e dinamica che attira visitatori da tutto il mondo.
                                       
                                        Inoltre, Madrid è ben collegata al resto della Spagna e dell'Europa tramite una rete efficiente di trasporti, tra cui treni ad alta velocità, autobus e aeroporti internazionali. La sua posizione centrale la rende una base ideale per esplorare il resto del paese e del continente.
                                       
                                        Madrid è una città che incanta e ispira, con la sua combinazione unica di storia, cultura e modernità. È il luogo perfetto per chiunque cerchi avventura, divertimento e bellezza in un'unica città.`
                                    },
                                    {
                                        name: 'Tokyo',
                                        description: 'La città dell’innovazione',
                                        foundation_year: '1457',
                                        population: 13929286,
                                        currency: 'Yen giapponese',
                                        language: 'Giapponese',
                                        area: '2191 km quadrati', 
                                        timezone: 'UTC+9',
                                        cover_image: 'img/tokyo/tokyo-cover.jpg', 
                                        main_image: 'img/tokyo/tokyo-main.jpg',    
                                        background_image1: 'img/tokyo/tokyo-bg1.jpg',  
                                        background_image2: 'img/tokyo/tokyo-bg2.jpg',
                                        background_image3: 'img/tokyo/tokyo-bg3.jpg',
                                        flag_image: 'img/tokyo/japan-flag.jpg',
                                        detailed_description: `Tokyo, la capitale del Giappone, è una metropoli dinamica e cosmopolita che fonde tradizione e modernità in un affascinante mix. Fondata nel XII secolo, Tokyo è cresciuta fino a diventare una delle città più grandi e influenti del mondo, con una popolazione che supera i 13 milioni di abitanti.

                                        La città è un tripudio di vita, colori e suoni, con grattacieli scintillanti che si ergono accanto a santuari antichi e mercati tradizionali. Tokyo è divisa in quartieri distinti, ognuno con la propria personalità e attrazioni uniche. Da Shibuya, con la sua famosa intersezione pedonale e la vivace vita notturna, a Akihabara, il quartiere dell'elettronica e degli anime, Tokyo offre esperienze per tutti i gusti.
                                       
                                        Tokyo è anche una mecca per gli appassionati di cultura e arte. La città ospita numerosi musei di fama mondiale, come il Tokyo National Museum e il Mori Art Museum, che offrono una vasta gamma di opere d'arte, reperti storici e mostre innovative. La cultura giapponese è in mostra in tutto il suo splendore nei templi antichi, nei festival tradizionali e nelle cerimonie religiose che si svolgono in tutta la città.
                                       
                                        Ma Tokyo è anche all'avanguardia della tecnologia e dell'innovazione. La città è il centro dell'industria tecnologica giapponese, con aziende leader mondiali nel settore dell'elettronica, dell'automotive e delle telecomunicazioni. Shibuya e Shinjuku sono i distretti centrali degli affari e della finanza, pulsanti di attività commerciali e finanziarie.
                                       
                                        Nonostante la sua frenesia, Tokyo è anche una città di parchi e spazi verdi, con aree come il Parco Ueno e il Giardino Nazionale Shinjuku Gyoen che offrono rifugi di pace e tranquillità nel cuore della metropoli. La città è anche rinomata per la sua cucina eccezionale, con una vasta gamma di ristoranti che offrono piatti tradizionali giapponesi e cucine internazionali.
                                       
                                        Tokyo è una città che non smette mai di stupire e affascinare, con la sua combinazione unica di tradizione e modernità. È un luogo dove il passato si incontra con il futuro, creando un'esperienza indimenticabile per chiunque la visiti.`
                                    },
                                    {
                                        name: 'Londra',
                                        description: 'La città della regina',
                                        foundation_year: '43',
                                        population: 8982000,
                                        currency: 'Sterlina britannica',
                                        language: 'Inglese',
                                        area: '1572 km quadrati',  
                                        timezone: 'UTC+0',
                                        cover_image: 'img/londra/londra-cover.jpg',  
                                        main_image: 'img/londra/londra-main.jpg',   
                                        background_image1: 'img/londra/londra-bg1.jpg',  
                                        background_image2: 'img/londra/londra-bg2.jpg',
                                        background_image3: 'img/londra/londra-bg3.jpg',
                                        flag_image: 'img/londra/england-flag.jpg',
                                        detailed_description: `Londra, la capitale del Regno Unito, è una città iconica e cosmopolita, con una storia millenaria e una vibrante vita contemporanea. Fondata dai Romani oltre 2000 anni fa, Londra è cresciuta fino a diventare una delle principali città globali, con una popolazione diversificata e una cultura ricca e sfaccettata.

                                        La città è un mix affascinante di antico e moderno, con monumenti storici come la Torre di Londra, il Palazzo di Westminster e il Tower Bridge che i ergono accanto a grattacieli scintillanti e architetture futuristiche. Londra è anche una città di parchi e spazi verdi, con parchi reali, giardini pubblici e tratti del fiume Tamigi che offrono rifugi di pace e tranquillità nel cuore della metropoli.
                                       
                                        Londra è un importante centro culturale, con una vivace scena artistica, teatrale e musicale. La città ospita alcuni dei migliori musei e gallerie d'arte del mondo, tra cui il British Museum, la National Gallery e la Tate Modern, che attraggono visitatori da tutto il mondo. Il West End è il cuore del teatro londinese, con una vasta gamma di spettacoli, musical e opere teatrali che si tengono ogni sera.
                                       
                                        Ma Londra è anche una città di quartieri distinti, ognuno con la propria personalità e attrazioni uniche. Da Covent Garden, con i suoi mercati vivaci e le stradine acciottolate, a Notting Hill, con le sue case colorate e il famoso mercato di Portobello Road, Londra offre esperienze per tutti i gusti. I quartieri multietnici come Camden Town e Brick Lane riflettono la diversità e l'inclusività della città, offrendo una vasta gamma di cucine internazionali e cultura di strada.
                                       
                                        Londra è anche un importante centro finanziario e commerciale, con una fiorente industria della moda, dei media e delle tecnologie. La città è un crocevia di culture e idee, con un'energia pulsante che attira talenti e imprenditori da tutto il mondo.
                                       
                                        Inoltre, Londra è ben collegata al resto del mondo tramite una rete di trasporti efficiente, tra cui metropolitana, autobus, treni e aeroporti internazionali. La sua posizione nel cuore dell'Europa la rende una base ideale per esplorare il continente e oltre.
                                       
                                        Londra è una città che incanta e ispira, con la sua storia affascinante, la sua cultura vibrante e la sua atmosfera cosmopolita. È un luogo dove il passato e il presente si fondono in un'esperienza indimenticabile per chiunque la visiti.`
                                    }
                                ];

                                // Preparazione dell'inserimento delle città nel database
                                const insertStatement = db.prepare(`INSERT INTO cities (
                                    name, description, foundation_year, population, currency,
                                    language, area, timezone, cover_image, main_image,
                                    background_image1, background_image2, background_image3,
                                    flag_image, detailed_description
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

                                // Inserimento effettivo delle città nel database
                                cities.forEach(city => {
                                    insertStatement.run(
                                        city.name,
                                        city.description,
                                        city.foundation_year,
                                        city.population,
                                        city.currency,
                                        city.language,
                                        city.area,
                                        city.timezone,
                                        city.cover_image,
                                        city.main_image,
                                        city.background_image1,
                                        city.background_image2,
                                        city.background_image3,
                                        city.flag_image,
                                        city.detailed_description,
                                        updateAverageRating(city.name)
                                    );
                                });

                                insertStatement.finalize((err) => {
                                    if (err) {
                                        console.error('Errore durante l\'inserimento delle città:', err.message);
                                    } else {
                                        console.log('Inserimento delle città completato.');
                                    }
                                });
                            }
                        }
                    });
                }
            });
        }
    });

    // Chiude la connessione al database SQLite
    db.close();
}


// Ottiene tutte le città dal database
function getCities() {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(DB_PATH);
        const query = `SELECT * FROM cities`;

        db.all(query, [], (err, rows) => {
            if (err) {
                reject(err);
            } else {
                resolve(rows);
            }
        });

        db.close(); 
    });
}

// Aggiorna la valutazione media per una città nel database
function updateAverageRating(cityName) {
    const db = new sqlite3.Database(DB_PATH);
    db.run(`UPDATE cities
            SET average_rating = (
                SELECT AVG(rating)
                FROM ratings
                WHERE city_name = ?
            )
            WHERE name = ?`, [cityName, cityName], function(err) {
        if (err) {
            console.error(err.message);
        } 
    });
}

// Aggiunge un voto di un utente per una città nel database
const addRating = async (userId, cityName, rating) => {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(DB_PATH);
        const sql = `INSERT INTO ratings (user_id, city_name, rating) VALUES (?, ?, ?)
                     ON CONFLICT(user_id, city_name) DO UPDATE SET rating=excluded.rating`;
        const params = [userId, cityName, rating];

        db.run(sql, params, function(err) {
            if (err) {
                reject(err);
            } else {
                resolve({ message: 'Voto registrato con successo' });
            }
        });
    });
};

// Ottiene la valutazione media di una città dal database
const getAverageRating = async (cityName) => {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(DB_PATH);
        const sql = `SELECT AVG(rating) AS averageRating
                     FROM ratings
                     WHERE city_name = ?`;
        db.get(sql, [cityName], (err, row) => {
            if (err) {
                reject(err);
            } else {
                resolve(row.averageRating || 0); // Se non ci sono voti, restituisci 0 come media
            }
        });
    });
};

// Ottiene una città dal database per nome
function getCityByName(name) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(DB_PATH);
        const query = 'SELECT * FROM cities WHERE name = ?';

        db.get(query, [name], (err, row) => {
            if (err) {
                reject(err);
            } else {
                resolve(row);
            }
            db.close();
        });
    });
}

// Aggiunge una nuova città nel database
function addCity(cityData) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(DB_PATH);
        const {
            name, description, foundation_year, population, currency,
            language, area, timezone, cover_image, main_image,
            background_image1, background_image2, background_image3,
            flag_image, detailed_description
        } = cityData;

        const query = `INSERT INTO cities (name, description, foundation_year, population, currency,
            language, area, timezone, cover_image, main_image, background_image1,
            background_image2, background_image3, flag_image, detailed_description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

        const params = [
            name, description, foundation_year, population, currency,
            language, area, timezone, cover_image, main_image,
            background_image1, background_image2, background_image3,
            flag_image, detailed_description
        ];

        db.run(query, params, function(err) {
            if (err) {
                reject(err);
            } else {
                resolve({ id: this.lastID, ...cityData });
            }
            db.close(); 
        });
    });
};

// Rimuove una città dal database per nome
const removeCityByName = (name) => {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(DB_PATH);
        const query = `DELETE FROM cities WHERE name = ?`;

        db.run(query, [name], function(err) {
            if (err) {
                reject(err);
            } else {
                resolve({ changes: this.changes });
            }
        });

        db.close();
    });
};

// Cerca tutte le città nel database il cui nome contiene una determinata stringa
function searchCitiesByName(name) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(DB_PATH);
        const query = `SELECT * FROM cities WHERE name LIKE ?`;
        const params = [`%${name}%`];
        db.all(query, params, (err, rows) => {
            if (err) {
                reject(err);
            } else {
                resolve(rows);
            }
        });
    });
}


module.exports = {
    initializeDatabase,
    getCities,
    getCityByName,
    searchCitiesByName,
    addCity,
    removeCityByName,
    updateAverageRating,
    addRating,
    getAverageRating
};
