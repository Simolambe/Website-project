document.addEventListener('DOMContentLoaded', () => {
    
    // Recupero di tutti gli elementi html
    const searchSection = document.getElementById('searchSection');
    const loginLink = document.getElementById('loginLink');
    const addCityLink = document.getElementById('addCity-link');
    const addCitySection = document.getElementById('addCitySection');
    const registerLink = document.getElementById('registerLink');
    const destinationSection = document.querySelector('.destinations');
    const searchForm = document.querySelector('.form-inline');
    const searchBar = document.querySelector('.search-bar');
    const destinationGrid = document.querySelector('.destination-grid');
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const favoriteDestinationGrid = document.querySelector('.favorite-destination-grid');
    const favoriteDestinationSection = document.querySelector('.favorite-cities');
    const logoutLink = document.getElementById('logout-Link');
    const deleteCityLink = document.getElementById('deleteCity-link');
    const deleteCityForm = document.getElementById('deleteCityForm');
    const deleteForm = document.getElementById('deleteForm');
    const addCityForm = document.getElementById('addCityForm');

    
    // Nascondi i form di login e registrazione inizialmente
    loginForm.style.display = 'none';
    signupForm.style.display = 'none';
    logoutLink.style.display = 'none';
    addCityLink.style.display = 'none'
    deleteCityLink.style.display = 'none';
    addCitySection.style.display = 'none';
    deleteCityForm.style.display = 'none';

    // Mostra la sezione di aggiungi città se il link viene cliccato (funzione dell'admin)
    addCityLink.addEventListener('click', (event) => {
        event.preventDefault();
        addCitySection.style.display = 'block';
        deleteCityForm.style.display = 'none';
        destinationSection.style.display = 'none';
        favoriteDestinationSection.style.display ='none';
        searchSection.style.display ='none';
    });

    // Mostra la sezione di rimuovi città se il link viene cliccato (funzione dell'admin)
    deleteCityLink.addEventListener('click', (event) => {
        event.preventDefault();
        deleteCityForm.style.display = 'block';
        addCitySection.style.display = 'none';
        destinationSection.style.display = 'none';
        favoriteDestinationSection.style.display ='none';
        searchSection.style.display ='none';
    });

    // Mostra la sezione del login se il link viene cliccato
    loginLink.addEventListener('click', (event) => {
        event.preventDefault();
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        destinationSection.style.display = 'none';
        favoriteDestinationSection.style.display ='none';
        searchSection.style.display ='none';
    });

    // Mostra la sezione della registrazione se il link viene cliccato
    registerLink.addEventListener('click', (event) => {
        event.preventDefault();
        signupForm.style.display = 'block';
        loginForm.style.display = 'none';
        destinationSection.style.display = 'none';
        favoriteDestinationSection.style.display ='none';
        searchSection.style.display ='none';
    });

    // Codice per mostrare i messaggi tramite modal 
    const showModal = (message) => {
        const modal = document.getElementById('customModal');
        const modalMessage = document.getElementById('modalMessage');
        modalMessage.textContent = message;
        modal.style.display = 'flex';
    };

    // Nascondi i modal se viene cliccata la X
    document.getElementById('closeModal').addEventListener('click', () => {
        document.getElementById('customModal').style.display = 'none';
    });

    // Nascondi i modal se si clicca fuori dalla modale
    window.addEventListener('click', (event) => {
        const modal = document.getElementById('customModal');
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Gestisce il submit del form di login
    document.getElementById('login').addEventListener('submit', function(event) {
        event.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        fetch('/api/sessions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        })
        .then(async response => {
            if (response.ok) {
                return response.json();
            } else {
                const err = await response.json();
                throw new Error(err.message || 'Login failed');
            }
        })
        .then(data => {
            showModal('Login effettuato con successo! Benvenuto ' + data);
            setTimeout(() => {
                window.location.href = '/';
                loginLink.style.display = 'none';
                registerLink.style.display = 'none';
            }, 2000); // Tempo per mostrare la modale prima di reindirizzare
        })
        .catch(error => {
            console.error('Errore durante il login:', error);
            showModal(error.message);
        });
    });

    // Gestisce il submit del form di registrazione
    document.getElementById('signup').addEventListener('submit', function(event) {
        event.preventDefault();
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;

        fetch('/api/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        })
        .then(response => {
            if (response.status === 201) {
                showModal('Registrazione effettuata con successo! Puoi ora effettuare il login.');
                setTimeout(() => {
                    window.location.href = '/';
                    loginLink.style.display = 'none';
                }, 2000); // Tempo per mostrare la modale prima di reindirizzare
            } else {
                throw new Error('Un utente si è già registrato con questa email');
            }
        })
        .catch(error => {
            console.error('Errore durante la registrazione:', error);
            showModal(error.message);
        });
    });

    // Funzione che verifica se l'utente è loggato, nel caso aggiorna la pagina di conseguenza tramite updateHeaderForLoggedInUser
    const isLoggedIn = () => {
        fetch('/api/user/favorites')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Utente non autenticato');
                }
                loadFavoriteCities();
                updateHeaderForLoggedInUser();
            })
            .catch(error => {
                console.error('L\'utente non è autenticato:', error);
                favoriteDestinationGrid.innerHTML = '<p>Per visualizzare le tue città preferite, effettua il login</p>';
            });
    };

    // Aggiorna l'header della pagina con i link relativi agli utenti loggati
    const updateHeaderForLoggedInUser = () => {
        const loginLink = document.getElementById('loginLink');
         const registerLink = document.getElementById('registerLink');
    
        loginLink.style.display = 'none';
        registerLink.style.display = 'none';
        logoutLink.style.display = 'block';
    
        logoutLink.addEventListener('click', (event) => {
            event.preventDefault();
            logoutUser();
        });
    
        // Controlla se l'utente loggato è l'admin enel caso aggiorna la pagina di conseguenza    
        fetch('/api/checkAdmin')
        .then(response => {
            if (!response.ok) {
                throw new Error('Utente non è Admin');
            }
            addCityLink.style.display = 'block'
            deleteCityLink.style.display = 'block';  
            favoriteDestinationSection.style.display ='none';
      
        })
        .catch(error => {
            console.error('L\'utente non è admin:', error);
        });
        };
        
    // Funzione per effettuare il logout se viene cliccato il relativo link di logout
    const logoutUser = () => {
            fetch('/logout')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Errore durante la disconnessione');
                }
                window.location.href = '/'; // Reindirizza alla home page
            })
            .catch(error => {
                console.error('Errore durante la disconnessione:', error);
            });
        };

    // Funzione per caricare tutte le città
    const loadCities = () => {
        fetch('/api/cities')
            .then(response => response.json())
            .then(cities => {
                destinationGrid.innerHTML = '';

                cities.forEach(city => {
                    const cityElement = document.createElement('a');
                    cityElement.href = `city.html?name=${encodeURIComponent(city.name)}`;
                    cityElement.classList.add('destination-link');
                    cityElement.innerHTML = `
                        <div class="destination">
                            <img src="${city.cover_image}" alt="${city.name}">
                            <h3>${city.name}</h3>
                            <h5>${city.description}</h5>
                        </div>
                    `;
                    destinationGrid.appendChild(cityElement);
                });
            })
            .catch(error => console.error('Errore nel caricamento delle città:', error));
        };

    // Funzione per caricare tutte le città preferite (se ci sono)
    const loadFavoriteCities = () => {

        fetch('/api/user/favorites')
        .then(response => response.json())
        .then(favoriteCities => {
            
          favoriteDestinationGrid.innerHTML = '';
    
          if (favoriteCities.length === 0) {
            favoriteDestinationGrid.innerHTML = '<p>Il tuo elenco di città preferite è vuoto</p>';
          }
    
          else{
          
          favoriteCities.forEach(city => {
            const cityElement = document.createElement('a');
            cityElement.href = `city.html?name=${encodeURIComponent(city.name)}`;
            cityElement.classList.add('destination-link');
            cityElement.innerHTML = `
              <div class="destination">
                <img src="${city.cover_image}" alt="${city.name}">
                <h3>${city.name}</h3>
                <h5>${city.description}</h5>
              </div>
            `;
            favoriteDestinationGrid.appendChild(cityElement);
          });
        }
        })
        .catch(error => console.error('Errore nel caricamento delle città preferite:', error));
        };


    // Listener per il submit del form di ricerca
    searchForm.addEventListener('submit', (event) => {
        event.preventDefault(); 

        const query = searchBar.value.trim();
        if (query) {
            const newUrl = `/search?name=${encodeURIComponent(query)}`;
            history.pushState({ path: newUrl }, '', newUrl);

            fetch(`/api/search?name=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(cities => {
                    destinationGrid.innerHTML = '';
                    if (cities.length > 0) {
                        cities.forEach(city => {
                            const cityElement = document.createElement('a');
                            cityElement.href = `city.html?name=${encodeURIComponent(city.name)}`;
                            cityElement.classList.add('destination-link');
                            cityElement.innerHTML = `
                                <div class="destination">
                                    <img src="${city.cover_image}" alt="${city.name}">
                                    <h3>${city.name}</h3>
                                    <p>${city.description}</p>
                                </div>
                            `;
                            destinationGrid.appendChild(cityElement);
                        });
                    } else {
                            destinationGrid.innerHTML = '<p></p>';
                          }
                })
                .catch(error => {
                    console.error('Errore durante la ricerca:', error);
                    destinationGrid.innerHTML = '<p>Errore durante la ricerca.</p>';
                });
             }
            });



    // Funzione per inviare i dati del form di aggiunta città (funzione dell'admin)
    addCityForm.addEventListener('submit', async (event) => {
        event.preventDefault(); 

        const formData = new FormData(addCityForm);
        const cityData = {
                name: formData.get('name'),
                description: formData.get('description'),
                foundation_year: formData.get('foundation_year'),
                population: parseInt(formData.get('population'), 10),
                currency: formData.get('currency'),
                language: formData.get('language'),
                area: formData.get('area'),
                timezone: formData.get('timezone'),
                cover_image: formData.get('cover_image'),
                main_image: formData.get('main_image'),
                background_image1: formData.get('background_image1'),
                background_image2: formData.get('background_image2'),
                background_image3: formData.get('background_image3'),
                flag_image: formData.get('flag_image'),
                detailed_description: formData.get('detailed_description')
        };

        try {
            const response = await fetch('/api/addCity', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(cityData)
            });

            if (!response.ok) {
                throw new Error('Errore durante l\'aggiunta della città');
            }
                const newCity = await response.json();
                console.log('Città aggiunta con successo:', newCity);
                window.location.href = '/';
            } catch (error) {
                console.error('Errore durante l\'aggiunta della città:', error);
            }
        });
            
    // Funzione per inviare i dati del form di rimuovi città (funzione dell'admin)    
    deleteForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        
        const cityName = document.getElementById('deleteCityName').value.trim();
        if (!cityName) {
        alert('Inserisci il nome della città da eliminare.');
        return;
        }
        
        try {
        const response = await fetch(`/api/removeCity?name=${encodeURIComponent(cityName)}`, {
            method: 'DELETE'
        });
        
            if (!response.ok) {
                throw new Error('Errore durante l\'eliminazione della città.');
            }
        
            const result = await response.json();
            console.log(result.message);
            window.location.href = '/';
            
            } catch (error) {
            alert('Errore durante l\'eliminazione della città.');
            }
        });

    // Gestisce la navigazione avanti e indietro della pagina 
    window.addEventListener('popstate', () => {
        const urlParams = new URLSearchParams(window.location.search);
        const query = urlParams.get('name');
        if (query) {
            searchBar.value = query;
            searchForm.dispatchEvent(new Event('submit'));
            }
         else {
            loadCities();
            }
        });

    loadCities(); // Carica tutte le città inizialmente
    isLoggedIn(); // Carica le città preferite se l'utente è loggato

});