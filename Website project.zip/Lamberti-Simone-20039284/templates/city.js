document.addEventListener('DOMContentLoaded', () => {
    // Ottiene il nome della città dai parametri URL
    const urlParams = new URLSearchParams(window.location.search);
    const cityName = urlParams.get('name');

    // Mostra i messaggi tramite modal
    const showModal = (message) => {
        const modal = document.getElementById('customModal');
        const modalMessage = document.getElementById('modalMessage');
        modalMessage.textContent = message;
        modal.style.display = 'flex';
    };

    // Nasconde il modal se viene cliccata la X
    document.getElementById('closeModal').addEventListener('click', () => {
        document.getElementById('customModal').style.display = 'none';
    });

    // Nasconde il modal se si clicca fuori dalla modale
    window.addEventListener('click', (event) => {
        const modal = document.getElementById('customModal');
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Recupera le informazioni sulla città dall'API
    fetch(`/api/cities/${encodeURIComponent(cityName)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Errore HTTP, status ' + response.status);
            }
            return response.json();
        })
        .then(city => {
            const cityElements = {
                'city-name': city.name,
                'main-image': city.main_image,
                'foundation-year': city.foundation_year,
                'flag-image': city.flag_image,
                'population': city.population,
                'city-title': city.name,
                'city-description': city.detailed_description,
                'currency': city.currency,
                'language': city.language,
                'area': city.area,
                'timezone': city.timezone,
                'image1': city.background_image1,
                'image2': city.background_image2,
                'image3': city.background_image3
            };

            // Popola gli elementi della città nel DOM
            Object.keys(cityElements).forEach(key => {
                const element = document.getElementById(key);
                if (element) {
                    if (element.tagName === 'IMG') {
                        element.src = cityElements[key];
                    } else {
                        element.textContent = cityElements[key];
                    }
                } else {
                    console.warn(`Elemento ${key} non trovato nel DOM`);
                }
            });

            // Aggiunge la città ai preferiti se viene cliccato il bottone
            const addToFavoritesBtn = document.getElementById('addToFavorites');
            if (addToFavoritesBtn) {
                addToFavoritesBtn.addEventListener('click', () => {
                    fetch(`/api/user/favorites/add`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ cityName })
                    })
                    .then(response => response.json())
                    .then(data => {
                        showModal(data.message);
                    })
                    .catch(error => {
                        console.error('Errore durante l\'aggiunta ai preferiti:', error);
                        showModal('Devi effettuare il login per utilizzare questa funzione');
                    });
                });
            } else {
                console.warn('Elemento #addToFavorites non trovato nel DOM');
            }

            // Rimuove la città dai preferiti se viene cliccato il bottone
            const removeFavoriteBtn = document.getElementById('removeFavorite');
            if (removeFavoriteBtn) {
                removeFavoriteBtn.addEventListener('click', () => {
                    fetch(`/api/user/favorites/remove`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ cityName })
                    })
                    .then(response => response.json())
                    .then(data => {
                        showModal(data.message);
                    })
                    .catch(error => {
                        console.error('Errore durante la rimozione dai preferiti:', error);
                        showModal('Devi effettuare il login per utilizzare questa funzione');
                    });
                });
            } else {
                console.warn('Elemento #removeFavorite non trovato nel DOM');
            }

            // Gestisce il rating della città
            document.querySelectorAll('.rating input').forEach(star => {
                star.addEventListener('change', () => {
                    const rating = star.value;
                    fetch(`/api/cities/rate`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ cityName, rating })
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Errore HTTP, status ' + response.status);
                        }
                        showModal('Grazie per il tuo voto!');
                    })
                    .catch(error => {
                        console.error('Errore durante l\'invio del voto:', error);
                        showModal('Devi effettuare il login per utilizzare questa funzione');
                    });
                });
            });

            // Aggiorna l'UI della media dei voti
            const updateAverageRatingUI = (averageRating) => {
                const averageRatingElement = document.getElementById('average-rating');
                if (averageRatingElement) {
                    averageRatingElement.textContent = `Media voti: ${averageRating.toFixed(1)}`;
                }
            };

            // Recupera la media dei voti dall'API
            fetch(`/api/cities/${encodeURIComponent(cityName)}/average-rating`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Errore HTTP, status ' + response.status);
                    }
                    return response.json();
                })
                .then(data => {
                    updateAverageRatingUI(data.averageRating);
                })
                .catch(error => {
                    console.error('Errore durante il recupero della media dei voti iniziale:', error);
                });

            // Recupera le notizie sulla città dall'API delle notizie
            const apiKey = 'bab88561ae1e4e1cbcff1a011211fec1';
            fetch(`https://newsapi.org/v2/everything?q=${encodeURIComponent(cityName)}&language=it&apiKey=${apiKey}`)
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    displayNews(data.articles);
                })
                .catch(error => {
                    console.error('Errore durante il recupero delle notizie:', error);
                });

            // Mostra le notizie nel DOM
            function displayNews(articles) {
                const newsContainer = document.getElementById('news-container');
                if (!newsContainer) {
                    console.warn('Elemento #news-container non trovato nel DOM');
                    return;
                }
                newsContainer.innerHTML = ''; // Pulisce le notizie esistenti
                const slicedArticles = articles.slice(0, 3); // Mostra solo le prime tre notizie
                slicedArticles.forEach(article => {
                    const newsItem = document.createElement('div');
                    newsItem.className = 'news-item';
                    newsItem.innerHTML = `
                        <img src="${article.urlToImage}" alt="news image">
                        <h3><a href="${article.url}" target="_blank">${article.title}</a></h3>
                        <p>${article.description}</p>
                    `;
                    newsContainer.appendChild(newsItem);
                });
            }

            // Recupera le informazioni meteo sulla città dall'API di OpenWeatherMap
            const weatherApiKey = '7e8f9d5f1484e84478caf40549261132';
            fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city.name)}&lang=it&appid=${weatherApiKey}&units=metric`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Errore HTTP, status ' + response.status);
                    }
                    return response.json();
                })
                .then(weatherData => {
                    displayWeather(weatherData);
                })
                .catch(error => {
                    console.error('Errore durante il recupero delle informazioni meteo:', error);
                });

            // Mostra le informazioni meteo nel DOM
            function displayWeather(weatherData) {
                const weatherContainer = document.getElementById('weather-container');
                if (!weatherContainer) {
                    console.warn('Elemento #weather-container non trovato nel DOM');
                    return;
                }

                const weatherHTML = `
                    <h3>Meteo attuale a ${weatherData.name}</h3>
                    <p>Cielo: ${weatherData.weather[0].description}</p>
                    <p>Temperatura: ${weatherData.main.temp} °C</p>
                    <p>Temperatura percepita: ${weatherData.main.feels_like} °C</p>
                    <p>Umidità: ${weatherData.main.humidity}%</p>
                    <p>Velocità del vento: ${weatherData.wind.speed} m/s</p>
                `;
                weatherContainer.innerHTML = weatherHTML;

                // Inizializza la mappa con le coordinate meteo
                initMap(weatherData.coord.lat, weatherData.coord.lon);
            }

            // Inizializza la mappa con le coordinate della città
            function initMap(lat, lon) {
                const map = L.map('map').setView([lat, lon], 12);

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                }).addTo(map);

                L.marker([lat, lon]).addTo(map)
                    .bindPopup(cityName)
                    .openPopup();
            }
        })
        .catch(error => {
            console.error('Errore durante il recupero delle informazioni sulla città:', error);
            showModal('Errore durante il recupero delle informazioni sulla città. Riprova più tardi.');
        });
});
