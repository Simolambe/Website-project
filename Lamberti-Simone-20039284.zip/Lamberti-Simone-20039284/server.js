
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();
const path = require('path');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const morgan = require('morgan');
const flash = require('express-flash');
const bodyParser = require('body-parser'); 
const SQLiteStore = require('connect-sqlite3')(session);
const userDao = require('./user-dao.js');

const {
    initializeDatabase,
    getCities,
    getCityByName,
    searchCitiesByName,
    addCity,
    removeCityByName,
    addRating,
    updateAverageRating,
    getAverageRating,  
} = require('./dao');

const DB_PATH = './cities.db';
initializeDatabase();

app.use(flash());
app.use(express.static('templates'));
app.use(express.static('public'));
app.use('/style.css', express.static(__dirname + '/style.css'));
app.use('/city.html', express.static(__dirname + '/city.html'));
app.use('/index.html', express.static(__dirname + '/index.html'));
app.use('/img', express.static(path.join(__dirname, 'img')));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true })); // Configura body-parser per l'uso
app.use(morgan('tiny'));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/templates', express.static(path.join(__dirname, 'templates'), {
  setHeaders: (res, path, stat) => {
      res.set('Content-Type', 'application/javascript');
  },
}));

// Configura la sessione
app.use(session({
  secret: 'una frase segreta da non condividere con nessuno, utilizzata per firmare il cookie dell\'ID di sessione',
  resave: false,
  saveUninitialized: false
}));

// Inizializza Passport
app.use(passport.initialize());
app.use(passport.session());

// Configurazione di Passport
passport.use(new LocalStrategy({
  usernameField: 'email',
  passwordField: 'password'
},
function(email, password, done) {
  userDao.getUserByEmail(email, password).then(({user, check}) => {
    if (!user) {
      return done(null, false, { message: 'Indirizzo email non corretto.' });
    }
    if (!check) {
      return done(null, false, { message: 'Password non corretta.' });
    }
    return done(null, user);
  }).catch(err => {
    return done(err);
  });
}
));

// Serializza e deserializza l'utente (oggetto utente <-> sessione)
passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  userDao.getUserById(id).then(user => {
    done(null, user);
  });
});

// POST /users
// Registrazione
app.post('/api/users',(req, res) => {
  // Crea un oggetto utente dal modulo di registrazione
  const user = {
    email: req.body.email,
    password: req.body.password,
  };

  userDao.createUser(user)
  .then((result) => res.status(201).header('Location', `/users/${result}`).end())
  .catch((err) => res.status(503).json({ error: 'Errore del database durante la registrazione'}));
});

// POST /sessions
// Login
app.post('/api/sessions', function(req, res, next) {
  console.log('Request body:', req.body);  // Log per il debug
  passport.authenticate('local', function(err, user, info) {
      if (err) {
          return next(err);
      }
      if (!user) {
          return res.status(401).json(info);
      }
      req.login(user, function(err) {
          if (err) {
              return next(err);
          }
          return res.json(req.user.username);
      });
  })(req, res, next);
});

// DELETE /sessions/current
// Logout
app.delete('/api/sessions/current', function(req, res){
  req.logout(); // Esegue il logout dell'utente
  res.end(); // Termina la risposta
});

// GET /
// Restituisce il file index.html come risposta alla richiesta GET sulla radice
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Middleware per verificare se l'utente è autenticato
function isLoggedIn(req, res, next) {
  // Supponendo che ci sia un metodo per verificare se l'utente è autenticato
  if (req.isAuthenticated()) {
    return next(); // L'utente è autenticato, continua al prossimo middleware o gestore di route
  } else {
    // L'utente non è autenticato, gestisce la risposta di conseguenza
    res.status(401).json({ message: 'Devi effettuare il login per usare questa funzione' });
  }
}

// Middleware per verificare se l'utente è un amministratore
const isAdmin = (req, res, next) => {
  if (req.isAuthenticated() && req.user && req.user.username === 'CityExplorerAdmin@gmail.com') {
    return next(); // L'utente è un amministratore, continua al prossimo middleware o gestore di route
  }
  return res.status(403).json({ statusCode: 403, message: 'Accesso vietato: non sei un amministratore' });
}

// GET /api/checkAdmin
// Verifica se l'utente è un amministratore
app.get('/api/checkAdmin', isAdmin, (req, res) => {
  res.json({ isAdmin: true }); // Invia una risposta che indica che l'utente è un admin
});

// GET /api/cities
// Ottiene tutte le città dal database
app.get('/api/cities', async (req, res) => {
    try {
        const cities = await getCities();
        res.json(cities);
    } catch (error) {
        console.error('Errore durante il recupero delle città:', error.message);
        res.status(500).json({ error: 'Errore del database' });
    }
});

// GET /api/cities/:name
// Ottiene una città specifica dal database per nome
app.get('/api/cities/:name', async (req, res) => {
    const name = req.params.name;
    try {
        const city = await getCityByName(name);
        if (city) {
            res.json(city);
        } else {
            res.status(404).json({ error: 'Città non trovata' });
        }
    } catch (error) {
        console.error('Errore durante il recupero della città:', error.message);
        res.status(500).json({ error: 'Errore del database' });
    }
});

// GET /api/search
// Cerca città per nome nel database
app.get('/api/search', async (req, res) => {
    const name = req.query.name;
    try {
        const cities = await searchCitiesByName(name);
        res.json(cities);
    } catch (error) {
        console.error('Errore durante la ricerca delle città:', error.message);
        res.status(500).json({ error: 'Errore del database' });
    }
});

// POST /api/cities/rate
// Aggiorna il voto di una città
app.post('/api/cities/rate', isLoggedIn, async (req, res) => {
  const userId = req.user.id; // Recupera l'ID dell'utente autenticato
  const { cityName, rating } = req.body;

  // Controlla se ci sono dati mancanti
  if (!cityName || !rating) {
      return res.status(400).json({ error: 'Missing data' });
  }

  try {
      // Inserisce o aggiorna il voto
      await addRating(userId, cityName, rating);

      // Aggiorna il voto medio
      updateAverageRating(cityName);

      res.status(200).json({ message: 'Rating updated successfully' });
  } catch (error) {
      res.status(500).json({ error: 'Failed to update rating' });
  }
});

// GET /api/cities/:cityName/average-rating
// Ottiene la media dei voti di una città specifica
app.get('/api/cities/:cityName/average-rating', async (req, res) => {
  const cityName = req.params.cityName;
  try {
      const averageRating = await getAverageRating(cityName);
      res.status(200).json({ averageRating });
  } catch (error) {
      console.error('Errore durante il recupero della media dei voti:', error);
      res.status(500).json({ error: 'Failed to retrieve average rating' });
  }
});

// POST /api/user/favorites/add
// Aggiunge una città ai preferiti dell'utente
app.post('/api/user/favorites/add', isLoggedIn, async (req, res) => {
  const userId = req.user.id; // Recupera l'ID dell'utente autenticato
  const cityName = req.body.cityName;

  try {
    const result = await userDao.addFavoriteCity(userId, cityName);
    if (result.alreadyExists) {
      res.status(200).json({ message: result.message, alreadyExists: true });
    } else {
      res.status(200).json({ message: result.message, alreadyExists: false });
    }
  } catch (error) {
    console.error('Errore durante l\'aggiunta ai preferiti:', error);
    res.status(500).json({ error: 'Errore durante l\'aggiunta ai preferiti. Riprova più tardi.' });
  }
});

// POST /api/user/favorites/remove
// Rimuove una città dai preferiti dell'utente
app.post('/api/user/favorites/remove', isLoggedIn, async (req, res) => {
  const userId = req.user.id; // Recupera l'ID dell'utente autenticato
  const cityName = req.body.cityName;

  try {
    const result = await userDao.removeFavoriteCity(userId, cityName);
    if (result.notInFavorites) {
      res.status(200).json({ message: result.message, notInFavorites: true });
    } else {
      res.status(200).json({ message: result.message, notInFavorites: false });
    }
  } catch (error) {
    console.error('Errore durante la rimozione dai preferiti:', error);
    res.status(500).json({ error: 'Errore durante la rimozione dai preferiti. Riprova più tardi.' });
  }
});

// GET /api/user/favorites
// Ottiene le città preferite dell'utente autenticato
app.get('/api/user/favorites', isLoggedIn, async (req, res) => {
  try {
    const userId = req.user.id; // Recupera l'ID dell'utente autenticato
    const favorites = await userDao.getUserFavorites(userId);
    res.json(favorites);
  } catch (error) {
    console.error('Errore durante il recupero delle città preferite:', error.message);
    res.status(500).json({ error: 'Errore durante il recupero delle città preferite.' });
  }
});

// GET /logout
// Effettua il logout dell'utente e reindirizza alla home page
app.get('/logout', function(req, res) {
  req.logout(function(err) {
    if (err) {
      console.error(err);
      return res.status(500).send('Errore durante la disconnessione');
    }
    res.redirect('/'); // Reindirizza l'utente alla home page
  });
});

// POST /api/addCity
// Aggiunge una nuova città al database
app.post('/api/addCity', isLoggedIn, isAdmin, async (req, res) => {
  const cityData = req.body;

  try {
    const newCity = await addCity(cityData);
    res.status(201).json(newCity); // Invia la città aggiunta come risposta
  } catch (error) {
    console.error('Errore durante l\'aggiunta della città:', error.message);
    res.status(500).json({ error: 'Database error' });
  }
});

// DELETE /api/removeCity
// Rimuove una città dal database per nome
app.delete('/api/removeCity', isLoggedIn, isAdmin, async (req, res) => {
  const name = req.query.name;

  try {
    const result = await removeCityByName(name);
    if (result.changes > 0) {
      res.json({ message: `Città ${name} rimossa con successo.` });
    } else {
      res.status(404).json({ error: `Città ${name} non trovata nel database.` });
    }
  } catch (error) {
    console.error('Errore durante la rimozione della città:', error.message);
    res.status(500).json({ error: 'Database error' });
  }
});

// Configurazione della porta e avvio del server
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server avviato su http://localhost:${port}`);
});

